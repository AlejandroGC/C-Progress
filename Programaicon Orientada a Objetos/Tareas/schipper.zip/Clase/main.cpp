#include <iostream>
#include "peliculas.hpp"
// #include "serie.hpp"
// ./"main.exe"
// Desarrollo: 5 horas

using namespace std;

void leerDatosPelicula(Pelicula &datosPelicula){
    int oscares;
    string id;
    string titulo;
    int duracion;
    string genero;
    double cPromedio;

    cout << "---Ingresa los datos de la pelicula---\n";
    cout << "Ingresa el iD: ";
    cin >> id;
    cin.ignore();
    datosPelicula.setId(id);

    cout << "Ingresa el titulo: ";
    getline(cin, titulo);
    datosPelicula.setTitulo(titulo);

    cout << "Ingresa la Duracion en minutos: ";
    cin >> duracion;
    datosPelicula.setDuracion(duracion);

    cout << "Ingresa Genero: ";
    cin >> genero;
    datosPelicula.setGenero(genero);

    cout << "Ingresa Calificacion: ";
    cin >> cPromedio;
    datosPelicula.setCalificacion(cPromedio);

    cout << "Ingresa Oscares: ";
    cin >> oscares;
    datosPelicula.setOscares(oscares);
    cin.ignore();
}

int menuPeliculas(){
    int iOpcion;
    cout << "\n1. Leer informacion desde Archivo" 
    << "\n2. Alta Pelicula" 
    << "\n3. Reporte de todas las peliculas"
    << "\n4. Reporte con Calificacion" 
    << "\n5. Reporte por genero" 
    << "\nTeclea la opcion: ";
    cin >> iOpcion;
    return iOpcion;
}

int main(int argc, const char *){
    Peliculas peliculas;
    Pelicula *ptrPelicula;
    int iOpcion, iCal;
    string genero;

    iOpcion = menuPeliculas();
    while(iOpcion != 0){
        switch (iOpcion){
            case 1:
                peliculas.leerArchivo();
                break;
            case 2:
                ptrPelicula = new Pelicula();
                leerDatosPelicula(*ptrPelicula);
                peliculas.setPtrPelicula(ptrPelicula);
                break;
            case 3:
                peliculas.str();
                break;
            case 4:
                cout << "Ingresa la calificacion: ";
                cin >> iCal;
                // peliculas.reporteConCalificacion(iCal);
                break;
            case 5:
                cout << "Ingresa el genero: ";
                cin >> genero;
                // peliculas.reporteGenero(genero);
                break;
            default:
                cout << "Error, opcion no existe. \n";
                break;
        }
        iOpcion = menuPeliculas();
    }
    return 0;
}
/*
int main() {
    int iOpcion;

		iOpcion = menu();
		while (iOpcion != 0){
			if (iOpcion == 1)
				alta();
			else if (iOpcion == 2)
				leer();
			
			else cout << "Opcion incorrecta!\n" ;
			iOpcion = menu();
		}

    
    return 0;
}
*/
