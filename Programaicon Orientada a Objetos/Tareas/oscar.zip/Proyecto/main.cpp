#include <string>
#include <iostream>
#include "peliculas.hpp"
#include "series.hpp"
// #include "serie.hpp"
// ./"main.exe"
// Desarrollo: 10 horas

using namespace std;

void leerDatosPelicula(Pelicula &datosPelicula){
    int oscares;
    string id;
    string titulo;
    int duracion;
    string genero;
    double cPromedio;

    cout << "---Ingresa los datos de la pelicula---\n";
    cout << "Ingresa el iD: ";
    cin >> id;
    cin.ignore();
    datosPelicula.setId(id);

    cout << "Ingresa el titulo: ";
    getline(cin, titulo);
    datosPelicula.setTitulo(titulo);

    cout << "Ingresa la Duracion en minutos: ";
    cin >> duracion;
    datosPelicula.setDuracion(duracion);

    cout << "Ingresa Genero: ";
    cin >> genero;
    datosPelicula.setGenero(genero);

    cout << "Ingresa Calificacion: ";
    cin >> cPromedio;
    datosPelicula.setCalificacion(cPromedio);

    cout << "Ingresa Oscares: ";
    cin >> oscares;
    datosPelicula.setOscares(oscares);
    cin.ignore();
}

int menuPeliculas(){
    int iOpcion;
    cout << ".*.*.*.*.*.*Peliculas.*.*.*.*.*.*"
    << "\n1. Leer Peliculas desde Archivo" //listo
    << "\n2. Alta Pelicula"  //listo
    << "\n3. Reporte de todas las peliculas" //listo
    << "\n4. Reporte con Calificacion" //listo
    << "\n5. Reporte por genero" // listo
    << "\n6. Cambiar Oscares de la Pelicula (cantOscares)" // listo
    << "\n\n.*.*.*.*.*.*Series.*.*.*.*.*.*" 
    << "\n7. Leer Series desde Archivo" // listo
    << "\n8. Reporte de todas las series" // listo
    << "\n9. Reporte de series con Calificacion" // listo
    << "\n10. Reporte de series por genero" //listo
    << "\n11. Agregar un episodio de una serie (idSerie)" 
    << "\n12. Calcular calificacion de serie en base a la calificacion de los episodios - (sobrecargar +)" // listo
    << "\n\n.*.*.*.*.*.*Episodios.*.*.*.*.*.*"
    << "\n13. Consulta todos los Episodios de una Serie (idSerie)" // listo
    << "\n14. Consulta todos los Episodios de una Serie con calificacion (idSerie, calificacion)" // listo
    << "\nTeclea la opcion: ";
    cin >> iOpcion;
    return iOpcion;
}

int main(){
    Peliculas peliculas;
    Pelicula *ptrPelicula;
    Serie *prtSerie;
    Series series;
    Episodio episodios;
    int iOpcion, itemporada, iSerie, iOscares;
    double iCal;
    string genero, iD;

    iOpcion = menuPeliculas();
    while(iOpcion != 0){
        switch (iOpcion){
            case 1:
                peliculas.leerArchivo();
                break;
            case 2:
                ptrPelicula = new Pelicula();
                leerDatosPelicula(*ptrPelicula);
                peliculas.setPtrPelicula(ptrPelicula);
                break;
            case 3:
                peliculas.str();
                break;
            case 4:
                cout << "Ingresa la calificacion: ";
                cin >> iCal;
                peliculas.reporteConCalificacion(iCal);
                break;
            case 5:
                cout << "Ingresa el genero: ";
                cin >> genero;
                peliculas.reporteGenero(genero);
                break;
            case 6:
                cout << "Ingrese id de la pelicula: ";
                cin >> iD;
                cout << "Ingresa la cantidad de oscares: ";
                cin >> iOscares;
            
                if (peliculas.getPtrPelicula(iD) != nullptr) {
                    // cout << "Cantidad de oscares actuales del ID: " << iD << endl << "Oscares antes: " << peliculas.getPtrPelicula(iD)->getOscares() << endl;
                    peliculas.getPtrPelicula(iD)->setOscares(iOscares);
                    cout << peliculas.getPtrPelicula(iD)->str() << endl;
                    cout << "Oscares despues: " << peliculas.getPtrPelicula(iD)->getOscares() << endl;
                }
                
                break;
            case 7:
                series.leerArchivo();
                break;
            case 8:
                series.str();
                break;
            case 9:
                cout << "Ingresa la calificacion: ";
                cin >> iCal;
                series.reporteConCalificacion(iCal);
                break;
            case 10:
                cout << "Ingresa el genero: ";
                cin >> genero;
                series.reporteGenero(genero);
                break;
            case 11:
                cout << "Ingresa ID de la serie: ";
                cin >> iD;
                series.alta(iD);
                break;
            case 12:
                series.calcularPromedioXSerie();
                series.str();
                break;
            case 13:
                cout << "Ingresa el ID: ";
                cin >> iD;
                series.consultaEpisodios(iD);
                break;
            case 14:
                cout << "Ingresa el ID: ";
                cin >> iD;
                cout << "Ingresa la calificacion: ";
                cin >> iCal;
                series.consultaEpisodiosConCalificacion(iD,iCal);
                break;
            default:
                cout << "Error, opcion no existe. \n";
                break;
        }
        iOpcion = menuPeliculas();
    }
    return 0;
}
