#ifndef serie_hpp
#define serie_hpp
#include "video.hpp"
#include "episodio.hpp"
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Serie : public Video{
private:
    Episodio *ptrEpisodios[5];
    int iCant;
public:
    Serie();
    Serie(string, string, int, string, double ,int, Episodio *arrPtrEpi[]);
    double calPromedio();
    void setEpisodio(int, Episodio *);
    Episodio getEpisodio(int);
    void setCantidadEpisodios(int);
    int getCantidadEpisodios();
    string str();
    void altaEpisodio(Episodio *ptrEpisodio);
};

Serie::Serie() {
    iCant = 0;
    for (int i = 0; i < 5; i++) {
        ptrEpisodios[i] = nullptr;
    }
    
}

// El orden importa
Serie::Serie(string id, string titulo, int duracion, string genero, double cPromedio, int iCant, Episodio *arrPtrEpi[]) : Video(id, titulo, duracion, genero, cPromedio){
    this->iCant = iCant;
    *ptrEpisodios = *arrPtrEpi;
}

double Serie::calPromedio() {
    double dPromedio;
    dPromedio = 0;
    for(int  iR = 0; iR < iCant; iR++){
        dPromedio = *ptrEpisodios[iR] + dPromedio;    
    }
    if (iCant > 0) {
        return dPromedio/iCant;
    } 
    return -1;
}


void Serie::setEpisodio(int epi, Episodio *arr) {
    ptrEpisodios[epi] = arr;
    epi++;
}


Episodio Serie::getEpisodio(int epi) {
    return *ptrEpisodios[epi];
}

void Serie::setCantidadEpisodios(int iCant) {
    this->iCant = iCant;
}

int Serie::getCantidadEpisodios() {
    return iCant;
}


string Serie::str() {
    string infoEpisodios = "";
    for (int iR = 0; iR < iCant; iR++) {
        infoEpisodios = infoEpisodios + ptrEpisodios[iR]->str() + "\n";
    }
    

    return Video::str() + ", " + to_string(iCant) + "\n" + infoEpisodios;
}


#endif // !serie_hpp


