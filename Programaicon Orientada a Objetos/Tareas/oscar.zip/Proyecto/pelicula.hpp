#ifndef pelicula_hpp
#define pelicula_hpp
#include "video.hpp"
#include <iostream>
#include <stdio.h>


using namespace std;


class Pelicula : public Video {
private:
    int oscares;
public:
    Pelicula();
    Pelicula(string, string, int, string, double, int);
    void setOscares(int);
    int getOscares();
    string str();
    double calPromedio();
};
 
//constructores

Pelicula::Pelicula(){
    oscares = 0;
}

Pelicula::Pelicula(string id, string titulo, int duracion, string genero, double cPromedio, int oscares) : Video(id, titulo, duracion, genero, cPromedio){
    this->oscares = oscares;
}

//sets y gets

void Pelicula::setOscares(int oscares){
    this->oscares = oscares;
}

int Pelicula::getOscares(){
    return oscares;
}

string Pelicula::str(){
    return Video::str() + ", " + to_string(oscares);
}

double Pelicula::calPromedio(){
    
}

#endif