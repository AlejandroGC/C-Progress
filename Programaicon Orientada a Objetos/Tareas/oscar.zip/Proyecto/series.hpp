#ifndef series_hpp
#define series_hpp
#include "serie.hpp"
#include <stdio.h>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

class Series{
private:
    Serie *arrPtrSeries[100];
    int iCant;
public:
    Series();
    void leerArchivo();
    void str();
    void reporteConCalificacion(double);
    void reporteGenero(string);
    Serie getPtrSerie(int);
    void consultaEpisodiosConCalificacion(string sID,double dCal);
    void consultaEpisodios(string sID);
    void calcularPromedioXSerie();
    Serie alta(string);

};

Series::Series(){
    iCant = 0;
    for (int i = 0; i < 100; i++) {
        arrPtrSeries[i] = nullptr;
    }
}

void Series::consultaEpisodiosConCalificacion(string ID, double dCal) {
    Serie consulta;
    for (int iR = 0; iR < iCant; iR++) {
        if (arrPtrSeries[iR]->getId() == ID) {
            for (int iEpisodio = 0; iEpisodio < arrPtrSeries[iR]->getCantidadEpisodios(); iEpisodio++) {
                if (arrPtrSeries[iR]->getEpisodio(iEpisodio).getCalificacion() == dCal) {
                    cout << arrPtrSeries[iR]->getEpisodio(iEpisodio).str() << endl;
                }
                
            }
            
        }
        
    }
    
}

void Series::consultaEpisodios(string ID) {
    Serie consulta;
    for (int iR = 0; iR < iCant; iR++) {
        if (arrPtrSeries[iR]->getId() == ID) {
            for (int iEpisodio = 0; iEpisodio < arrPtrSeries[iR]->getCantidadEpisodios(); iEpisodio++) {
                cout << arrPtrSeries[iR]->getEpisodio(iEpisodio).str() << endl;
            }
            
        }
        
    }
    
}

Serie Series::alta(string id) {
    Serie alta;
    for (int i = 0; i < iCant; i++) {
        if (arrPtrSeries[i]->getId() == id) {
            int cant = arrPtrSeries[i]->getCantidadEpisodios();
            cant = cant + 1;
            arrPtrSeries[i]->setCantidadEpisodios(cant);   
            return *arrPtrSeries[i];
        }
        
    }
    return alta;
}


void Series::leerArchivo(){
    // File pointer
    fstream fin;
    int iEpisodio = 0;

    int arrIdSerie[150];

    Episodio *arrPtrEpisodio[150];
    Episodio *arrPtrEpi[5];
    
    string algo;
    // Open an existing file
    fin.open("Episodios.csv", ios::in);
    
    
    // Read the Data from the file
    // as String array
    string row[6];
    string line, word;

    while ( getline(fin, line)) {
        // read an entire row and 
        // store it in a string variable 'line'.
        
        cout << line << endl;
        // used for breaking words.
        stringstream s(line);
        
        // read every column data of a row and
        // store it in a string variable, 'word'
        int iR = 0;
        // extrae caracteres de s  y los almacena en word hasta que encuentra el delimitador ','
        while (getline(s, word, ',')) {
            // add all the column data
            // of a row to a vector
            row[iR++]=word;
        }

        arrPtrEpisodio[iEpisodio] = new Episodio();
        
        cout << "Serie: " << row[0] << "\n";
        cout << "Titulo: " << row[1] << "\n";
        cout << "Temporada: " << row[2] << "\n";
        cout << "Calificacion: " << row[3] << "\n";

        arrIdSerie[iEpisodio] = stoi(row[0]);
        // arrPtrEpisodio[iEpisodio]->setTitulo(row[1]);
        // arrPtrEpisodio[iEpisodio]->setTemporada(stoi(row[2]));
        // arrPtrEpisodio[iEpisodio]->setCalificacion(stod(row[3]));

        for (int iR = 0; iR < 5; iR++) {
           arrPtrEpi[iR] = nullptr;
        }

        arrPtrEpisodio[iEpisodio] = new Episodio(row[1], stoi(row[2]), stod(row[3]));

        cout << "***" << arrPtrEpisodio[iEpisodio]->str() << endl;

        iEpisodio++;

    }
    fin.close();

    for (int iR = 0; iR < iEpisodio; iR++) {
        cout << "!" << arrPtrEpisodio[iR]->str() << endl;
    }
    

    cout << "========================================================== Reporte de Series =====================\n";

    // Open an existing file
    fin.open("ArchivoSerie.csv", ios::in);
    iCant = 0;
    
    // Read the Data from the file
    // as String array

    while ( getline(fin, line)) {
        // read an entire row and 
        // store it in a string variable 'line'.
        
        cout << iCant << " : "<< line << endl;
        // used for breaking words.
        stringstream s(line);
        
        // read every column data of a row and
        // store it in a string variable, 'word'
        int iR = 0;
        // extrae caracteres de s  y los almacena en word hasta que encuentra el delimitador ','
        while (getline(s, word, ',')) {
            // add all the column data
            // of a row to a vector
            row[iR++]=word;
        }
        
        cout << "iD " << row[0] << " : \n";
        cout << "Titulo: " << row[1] << "\n";
        cout << "Duracion: " << row[2] << "\n";
        cout << "Genero: " << row[3] << "\n";
        cout << "Calificacion: " << row[4] << "\n";
        cout << "Episodios Totales: " << row[5] << "\n";

        /*
        arrPtrSeries[iCant]->setId(row[0]);
        arrPtrSeries[iCant]->setTitulo(row[1]);
        arrPtrSeries[iCant]->setDuracion(stoi(row[2]));
        arrPtrSeries[iCant]->setGenero(row[3]);
        arrPtrSeries[iCant]->setCalificacion(stoi(row[4]));
        arrPtrSeries[iCant]->setEpisodio(stoi(row[5]));
        */

       for (int iR = 0; iR < 5; iR++) {
           arrPtrEpi[iR] = nullptr;
       }

       arrPtrSeries[iCant] = new Serie(row[0], row[1], stoi(row[2]), row[3], stod(row[4]), stoi(row[5]), arrPtrEpi);
       
       int iE = 0;
       for (int iEpi = 0; (iEpi < iEpisodio) & (iE < 5); iEpi++) {
           if (arrIdSerie[iEpi] == stoi(row[0])) {
               //cout << "Si fue igual\n";
               //arrPtrEpi[iE] = arrPtrEpisodio[iEpi];

               arrPtrSeries[iCant]->setEpisodio(iE, arrPtrEpisodio[iEpi]);
               iE++;
           }
       }
        arrPtrSeries[iCant]->setCantidadEpisodios(iE);
        iCant = iCant + 1;
        
    }
    fin.close();
}

void Series::reporteConCalificacion(double calificacion) {
    for(int  iR = 0; iR < iCant; iR++){
        if (arrPtrSeries[iR]->getCalificacion() == calificacion) {
            cout << arrPtrSeries[iR]->str() << endl;
        }
    }
}

void Series::reporteGenero(string sGenero) {
    for(int  iR = 0; iR < iCant; iR++){
        if (arrPtrSeries[iR]->getGenero() == sGenero) {
            cout << arrPtrSeries[iR]->str() << endl;
        }
    }
}

void Series::str() {
    double dPromedio;
    dPromedio = 0;
    for(int  iR = 0; iR < iCant; iR++){
        cout <<"---------------------------------------------------------------------------------------\n";
        cout << arrPtrSeries[iR]->str() << endl;
        dPromedio = dPromedio + arrPtrSeries[iR]->getCalificacion();
    }
    cout << "Promedio Series: " << dPromedio / iCant << endl;
}

Serie Series::getPtrSerie(int iSerie) {
    Serie serie;
    if (iSerie >= 0 && iSerie <= iCant) {
        return (*arrPtrSeries[iSerie]);
    } else {
        return serie;
    }
    
}

void Series::calcularPromedioXSerie() {
    for (int iR = 0; iR < iCant; iR++) {
        arrPtrSeries[iR]->setCalificacion(arrPtrSeries[iR]->calPromedio());
    }
}




#endif // !series_hpp
