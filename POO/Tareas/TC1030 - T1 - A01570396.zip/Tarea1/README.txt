Alejandro Gonzalez
ITESM
A01570396

Como se corre el codigo?
	- Para correr el codigo hay que dirigirse a la pagina de repl.it en donde podra correr su codigo de una manera gratuita sin necesidad de 
	  tener una interfaz de desarrollo, en tal caso de tener un IDE utilice el de su preferencia. Para correr codigo en IDE le recomendaria usar 
	  codeblocks o xcode, en el especial caso de utilizar otra interfaz investigue en youtube como correr c++ en su interfaz. Para repl.it lo 
	  unico que tienes que hacer es hacer copiar en el codigo y lo pegamos en la pagina. Finalmente hay mismo esta el boton de correr 
	  codigo (No hay necesidad de registrarse).

Cuales son los conceptos de programacion orientada a objetos utilizados?
	- Los conceptos utilizados en el desarrollo de este programa fueron clases y objetos, aunque no se haya utilizado la herencia 
	  todavia, sigo dispuesto a aprender todos esos diferentes terminos y como funcionan. Tambien se utilizaron los metodos y constructores para cada una de las 	  clases. Las clases se utilizaron para cada una de las cosas fisicas en el juego. Los objetos fueron los objetos fisicos creados por las clases cada uno con 	  sus metodos y atributos.

Porque lo diseñe asi?
	- Primero que nada no se me ocurria como debia dividir las clases para cada parte del codigo eso hizo que me atrasara mas con la entrega. Cuando tuvimos la 	          asesoria observer como la maestra dividia por cada cosa fisica del juego, como los jugadores, el tablero, el dado y el juego en general realizaba una clase.            Desde ese momento me deje llevar y comence primero con el tablero el cual se me ocurrio que fuera un arreglo ya que de un arreglo puedes obtener el valor de            un indice que tu le brindes. Entonces con eso lograba sacar la posicion del tablero en relacion al jugador. Para la realizacion de los jugadores se me 	  	  ocurrio crear la clase jugador que de esta se crearon los objetos jugador 1 y jugador 2 cada uno con sus atributos y metodos. En este caso metodos como si 	  	  querian continuar, que posicion estaban, que turno tenian, que posicion inicial y final tenian, etc. El dado utilice el proporcionado por la maestra que era 	  	  una clase con un metodo de numero aleatorio entre 1 y 6. Y finalmente se unio todo con la clase MyGame la cual se dedicaba a unir todo el juego, en esta se 	  	  nos pidio realizar todo el codigo aparte, no en el main. El main lo unio que hizo fue correr la clase.