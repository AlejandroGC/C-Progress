#ifndef pelicula_hpp
#define pelicula_hpp
#include "video.hpp"
#include <iostream>
#include <stdio.h>


using namespace std;


class Pelicula : public Video {
private:
    int oscares;
public:
    Pelicula();
    Pelicula(string, string, string, int, double, int);
    void setOscares(int);
    int getOscares();
    string str();
};
 
//constructores

Pelicula::Pelicula(){
    oscares = 0;
}

Pelicula::Pelicula(string id, string titulo, string genero, int duracion, double cPromedio, int oscares) : Video(id, titulo, genero, duracion, cPromedio){
    this->oscares = oscares;
}

//sets y gets

void Pelicula::setOscares(int oscares){
    this->oscares = oscares;
}

int Pelicula::getOscares(){
    return oscares;
}

string Pelicula::str(){
    return Video::str() + ", " + to_string(oscares);
}


#endif