#ifndef peliculas_hpp
#define peliculas_hpp
#include "pelicula.hpp"
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

class Peliculas : public Pelicula{
    private:
        Pelicula *arrPtrPeliculas[100];
        int iCant; 
    public:
        Peliculas();
        void leerArchivo();
        void reporteConCalificacion(double);
        void reporteGenero(string);
        void str();
        void setPtrPelicula(Pelicula *ptr);
        Pelicula getPtrPelicula(int); 
    
};

Peliculas::Peliculas(){
    iCant = 0;
    for (int i = 0; i < 100; i++) {
        arrPtrPeliculas[i] = nullptr;
    }
}



void Peliculas::leerArchivo(){
    // File pointer
    fstream fin;
    
    // Open an existing file
    fin.open("Peliculas.csv", ios::in);
    
    
    // Read the Data from the file
    // as String array
    string row[6];
    string line, word;

    while ( getline(fin, line)) {
        // read an entire row and 
        // store it in a string variable 'line'.
        
        cout << line << endl;
        // used for breaking words.
        stringstream s(line);
        
        // read every column data of a row and
        // store it in a string variable, 'word'
        int iR = 0;
        // extrae caracteres de s  y los almacena en word hasta que encuentra el delimitador ','
        while (getline(s, word, ',')) {
            // add all the column data
            // of a row to a vector
            row[iR++]=word;
        }

        arrPtrPeliculas[iCant] = new Pelicula();
        
        
        cout << "iD " << row[0] << " : \n";
        cout << "Titulo: " << row[1] << "\n";
        cout << "Duracion: " << row[2] << "\n";
        cout << "Calificacion: " << row[3] << "\n";
        cout << "Genero: " << row[4] << "\n";
        cout << "Oscares: " << row[5] << "\n";

        arrPtrPeliculas[iCant]->setId(row[0]);
        arrPtrPeliculas[iCant]->setTitulo(row[1]);
        arrPtrPeliculas[iCant]->setDuracion(stoi(row[2]));
        arrPtrPeliculas[iCant]->setGenero(row[3]);
        arrPtrPeliculas[iCant]->setCalificacion(stoi(row[4]));
        arrPtrPeliculas[iCant]->setOscares(stoi(row[5]));

        cout << arrPtrPeliculas[iCant]->str() << endl;
        iCant = iCant + 1;
    }
    fin.close();
}

void Peliculas::reporteConCalificacion(double calificacion){
    for(int  iR = 0; iR < iCant; iR++){
        if (arrPtrPeliculas[iR]->getCalificacion() == calificacion) {
            cout << arrPtrPeliculas[iR]->str() << endl;
        }
    }
}

void Peliculas::reporteGenero(string genero) {
    for(int  iR = 0; iR < iCant; iR++){
        if (arrPtrPeliculas[iR]->getGenero() == genero) {
            cout << arrPtrPeliculas[iR]->str() << endl;
        }   
    }
}

void Peliculas::str(){
    double dPromedio;
    dPromedio = 0;
    cout << "id       titulo      duracion     genero     calificacion     oscares\n";
    cout <<"-------------------------------------------------------------------------\n";
    for(int  iR = 0; iR < iCant; iR++){
        cout << arrPtrPeliculas[iR]->str() << endl;
        dPromedio = dPromedio + arrPtrPeliculas[iR]->getCalificacion();    
    }
    cout << "Promedio Peliculas: " << dPromedio / iCant << endl;
}


void Peliculas::setPtrPelicula(Pelicula *ptr){
    arrPtrPeliculas[iCant++] = ptr;
}



#endif // !peliculas.hpp

