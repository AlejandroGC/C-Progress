// Alejandro Gonzalez
// A01570396
// Trabajo en Clase SobreCarga

#include <stdio.h>
#include <iostream>
#include "Fracciones.cpp"

using namespace std;

int menu(){
    int iOpcion;
    cout << "\n1. Ingresa la Fraccion1:";
    cout << "\n2. Ingresa la fraccion2:";
    cout << "\n3. f1 + f2 ";
    cout << "\n4. f1 - f2 ";
    cout << "\n5. f1 * f2 ";
    cout << "\n6. f1 / f2 ";
    cout << "\n0. Salir";
    cout << "\nTeclea la opcion:";
    cin >> iOpcion;
    return iOpcion;
}
int main() {
    Fracciones f1(3,5), f2(1,5);
    Fracciones f3(3,5), f4(2,6);
    Fracciones resultado;
    int iOpcion, iNum, iDen;
    // resultado = f1 + f2;
    // cout << f1.show() << " + " << f2.show() << "= " << resultado.show() << endl;
    // resultado = f3 + f4;
    // cout << f3.show() << " + " << f4.show() << "= " << resultado.show() << endl;
    
    // Inicializar la vcc antes del ciclo
    iOpcion = menu();
    while (iOpcion != 0) {
        switch (iOpcion) {
            case 1:
                f1.input();
                f1.output();
                break;
            case 2:
                f2.input();
                f2.output();
                break;
            case 3:
                resultado = f1 + f2;
                cout << f1.show() << " + " << f2.show() << " = " << resultado.show() <<  " = " << resultado.strFlotante()<< endl;
                break;
            case 4:
                resultado = f1 - f2;
                cout << f1.show() << " - " << f2.show() << " = " << resultado.show() <<  " = " << resultado.strFlotante()<< endl;
                break;
            case 5:
                resultado = f1 * f2;
                cout << f1.show() << " * " << f2.show() << " = " << resultado.show() <<  " = " << resultado.strFlotante()<< endl;
                break;
            case 6:
                resultado = f1 / f2;
                cout << "(" << f1.show() << ") / (" << f2.show() << ") = " << resultado.show() <<  " = " << resultado.strFlotante()<< endl;
                break;
            default:
                break;
        }
        // Actualizar la vcc dentro del ciclo
        iOpcion = menu();
    }// fin while
    
    return 0;
}
